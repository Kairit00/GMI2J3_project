using System.Security.AccessControl;
using Tre_i_rad;
namespace Tic_tac_toe_test
{
    [TestClass]
    public class CPUTest
    {
        //              ----- Check for no threaths -------
        [TestMethod]
        [DataRow("_", "X", "_", "_", "_", "_", "_", "_", "_")]
        public void cpucheckthreats_nothreats(params string[] board)
        {
            //arrange
            string player = "X";
            List<int> legalMoves = Board.CheckLegalMoves();
            int expectedMove = -1; //No threat, CPU should not block

            //act
            int CPUMove = CPU.CheckThreat(player, board, legalMoves);

            //assert
            Assert.AreEqual(expectedMove, CPUMove);
        }

        //          ------ Horizontal threats --------
        [TestMethod]
        [DataRow(new string[] { "X", "X", "_", "_", "_", "_", "_", "_", "_" }, 2)]
        [DataRow(new string[] { "X", "_", "X", "_", "_", "_", "_", "_", "_" }, 1)]
        [DataRow(new string[] { "_", "X", "X", "_", "_", "_", "_", "_", "_" }, 0)]
        [DataRow(new string[] { "_", "_", "_", "_", "X", "X", "_", "_", "_" }, 3)]
        [DataRow(new string[] { "_", "_", "_", "X", "_", "X", "_", "_", "_" }, 4)]
        [DataRow(new string[] { "_", "_", "_", "X", "X", "_", "_", "_", "_" }, 5)]
        [DataRow(new string[] { "_", "_", "_", "_", "_", "_", "_", "X", "X" }, 6)]
        [DataRow(new string[] { "_", "_", "_", "_", "_", "_", "X", "_", "X" }, 7)]
        [DataRow(new string[] { "_", "_", "_", "_", "_", "_", "X", "X", "_" }, 8)]
        public void cpucheckthreats_horizontalthreats(string[] board, int expectedMove)
        {
            // Arrange
            string player = "X";
            List<int> legalMoves = Board.CheckLegalMoves();

            // Act
            int cpuMove = CPU.CheckThreat(player, board, legalMoves);

            // Assert
            Assert.AreEqual(expectedMove, cpuMove);
        }

        //          ----- Vertical threats --------
        [TestMethod]
        [DataRow(new string[] { "_", "_", "_", "X", "_", "_", "X", "_", "_" }, 0)]
        [DataRow(new string[] { "X", "_", "_", "_", "_", "_", "X", "_", "_" }, 3)]
        [DataRow(new string[] { "X", "_", "_", "X", "_", "_", "_", "_", "_" }, 6)]
        [DataRow(new string[] { "_", "_", "_", "_", "X", "_", "_", "X", "_" }, 1)]
        [DataRow(new string[] { "_", "X", "_", "_", "_", "_", "_", "X", "_" }, 4)]
        [DataRow(new string[] { "_", "X", "_", "_", "X", "_", "_", "_", "_" }, 7)]
        [DataRow(new string[] { "_", "_", "_", "_", "_", "X", "_", "_", "X" }, 2)]
        [DataRow(new string[] { "_", "_", "X", "_", "_", "_", "_", "_", "X" }, 5)]
        [DataRow(new string[] { "_", "_", "X", "_", "_", "X", "_", "_", "_" }, 8)]
        public void cpucheckthreats_verticalthreats(string[] board, int expectedMove)
        {
            // Arrange
            string player = "X";
            List<int> legalMoves = Board.CheckLegalMoves();

            // Act
            int cpuMove = CPU.CheckThreat(player, board, legalMoves);

            // Assert
            Assert.AreEqual(expectedMove, cpuMove);
        }

        //          ------- Diagonal threats ---------
        [TestMethod]
        [DataRow(new string[] { "_", "_", "_", "_", "X", "_", "_", "_", "X" }, 0)]
        [DataRow(new string[] { "X", "_", "_", "_", "_", "_", "_", "_", "X" }, 4)]
        [DataRow(new string[] { "X", "_", "_", "_", "X", "_", "_", "_", "_" }, 8)]
        [DataRow(new string[] { "_", "_", "_", "_", "X", "_", "X", "_", "_" }, 2)]
        [DataRow(new string[] { "_", "_", "X", "_", "_", "_", "X", "_", "_" }, 4)]
        [DataRow(new string[] { "_", "_", "X", "_", "X", "_", "_", "_", "_" }, 6)]
        public void cpucheckthreats_diagonalthreats(string[] board, int expectedMove)
        {
            // Arrange
            string player = "X";
            List<int> legalMoves = Board.CheckLegalMoves();

            // Act
            int cpuMove = CPU.CheckThreat(player, board, legalMoves);

            // Assert
            Assert.AreEqual(expectedMove, cpuMove);
        }

    }
}