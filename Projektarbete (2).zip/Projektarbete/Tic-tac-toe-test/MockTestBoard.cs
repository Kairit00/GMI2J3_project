﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq; 
using Tre_i_rad;
using Tre_i_rad.DataStructure;

namespace Tre_i_rad.Tests
{
    [TestClass]
    public class BoardTests
    {
        private Mock<StackDatastructure> _mockStack;
        private Board _board;

        public BoardTests()
        {
            _mockStack = new Mock<StackDatastructure>(); //Create mock object of the datastructure
            _board = new Board();
            // Inject the mocked StackDatastructure into the Board classokok
            Board._stackDatastructure = _mockStack.Object;
        }

        //              ------ ADD -----------
        [TestMethod]
        public void Add_ShouldSaveBoardState()
        {
            // Arrange
            int position = 0;
            string player = "X";
            //Sets up behaviour of the mock object, should return true
            _mockStack.Setup(stack => stack.Add(It.IsAny<string[]>())).Returns(true);

            // Act
            Board.Add(position, player);

            // Assert
            //Verify that the Add-method works are intended
            _mockStack.Verify(stack => stack.Add(It.Is<string[]>(board => board[position] == player)), Times.Once);
        }

        //                  ------ UNDO MOVE -----
        [TestMethod]
        public void UndoMove_ShouldRestorePreviousState()
        {
            // Arrange
            // previous board state
            _mockStack.Setup(stack => stack.GetLast()).Returns(new string[] { "_", "_", "_", "_", "_", "_", "_", "_", "_" });
            _mockStack.Setup(stack => stack.RemoveLast()).Returns(true);

            // Act
            Board.UndoMove();

            // Assert
            _mockStack.Verify(stack => stack.RemoveLast(), Times.Exactly(2));
            _mockStack.Verify(stack => stack.GetLast(), Times.Once);
            CollectionAssert.AreEqual(new string[] { "_", "_", "_", "_", "_", "_", "_", "_", "_" }, Board.ActiveBoard); // previous board state has been restored
        }

        //                      ------ CHECK LEGAL MOVES  -------
        [TestMethod]
        public void CheckLegalMoves_ShouldReturnAllEmptyPositions()
        {
            // Arrange
            string[] initialBoard = { "_", "X", "_", "O", "_", "_", "X", "_", "O" }; //initial state of board
            Board.ActiveBoard = initialBoard;

            // Act
            List<int> legalMoves = Board.CheckLegalMoves();

            // Assert
            List<int> expectedLegalMoves = new() { 0, 2, 4, 5, 7 }; // which moves it should take
            CollectionAssert.AreEqual(expectedLegalMoves, legalMoves); //checking so that the moves are used
        }

        //                      ----- CLEAR BOARD -----
        [TestMethod]
        public void Clear_ShouldResetBoard()
        {
            // Act
            Board.Clear();

            // Assert
            CollectionAssert.AreEqual(new string[] { "_", "_", "_", "_", "_", "_", "_", "_", "_" }, Board.ActiveBoard);
        }
    }
}

