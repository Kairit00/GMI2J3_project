﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tre_i_rad;

namespace Tic_tac_toe_test
{
    [TestClass]
    public class GameTest
    {
        //          ----- Test win horizontally  --------
        [TestMethod]
        [DataRow("X", "X", "X", "_", "_", "_", "_", "_", "_")]
        [DataRow("_", "_", "_", "X", "X", "X", "_", "_", "_")]
        [DataRow("_", "_", "_", "_", "_", "_", "X", "X", "X")]
        public void CheckWin_PlayerWinsHorizontally(params string[] board)
        {
            //Arrange
            string player = "X"; 

            //act
            bool result = Game.CheckWin(player, board); 

            //assert 
            Assert.IsTrue(result); 
        }

        //           ----- Test win verically ------
        [TestMethod]
        [DataRow("X", "_", "_", "X", "_", "_", "X", "_", "_")]
        [DataRow("_", "X", "_", "_", "X", "_", "_", "X", "_")]
        [DataRow("_", "_", "X", "_", "_", "X", "_", "_", "X")]
        public void CheckWin_PlayerWinsVertically(params string[] board)
        {
            //Arrange
            string player = "X"; 

            //act
            bool result = Game.CheckWin(player, board); 

            //assert 
            Assert.IsTrue(result);
        }

        //          --------- Test win diagonally ---------
        [TestMethod]
        [DataRow("X", "_", "_", "_", "X", "_", "_", "_", "X")]
        [DataRow("_", "_", "X", "_", "X", "_", "X", "_", "_")]
        public void CheckWin_PlayerWinsDiagonally(params string[] board)
        {
            //Arrange
            string player = "X"; 

            //act
            bool result = Game.CheckWin(player, board); 

            //assert 
            Assert.IsTrue(result); 
        }

        //                  ------ Test Lose ----------
        [TestMethod]
        [DataRow("X", "O", "O", "O", "X", "_", "_", "_", "_")]
        public void CheckLose_playerLoses(params string[] board)
        {
            //Arrange
            string player = "X";

            //Act
            bool result = Game.CheckWin(player, board); 

            //Assert
            Assert.IsFalse(result); 
        }

        //            ----- Test if it's a draw ----------
        [TestMethod]
        public void CheckDraw_itsADraw()
        {
            // Arrange
            string[] fullBoard = { "X", "O", "X", "X", "O", "O", "O", "X", "X" };
            string player = "X";

            // Act
            bool result = Game.CheckDraw(player, fullBoard);

            // Assert
            Assert.IsTrue(result);
        }

    }
}
