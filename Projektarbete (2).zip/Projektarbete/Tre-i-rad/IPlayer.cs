﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tre_i_rad
{
    internal interface IPlayer
        //                      CPU and Players common function
    {
        void MakeMove(string player, string[] activeBoard, List<int> legalMoves);
    }
}
