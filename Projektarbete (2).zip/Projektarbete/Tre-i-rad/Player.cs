﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tre_i_rad
{
    internal class Player : IPlayer
        //                          The player's class
    {
        bool recentUndo = false;

        public void MakeMove(string player, string[] activeBoard, List<int> legalMoves)
        {
            int playerMove = -1;
            bool isLegal = false;
            

            Console.WriteLine("\nWhat move would you like to make? Enter a number 0-8. Press 'E' to undo your latest move.");
            var input = Console.ReadLine().ToUpper();


            //          Undo-function
            if (input == "E")
            {
                if (recentUndo == false) 
                {
                    recentUndo = true;
                    Board.UndoMove();
                    Board.Display();
                }
                else
                {
                    // Invalid moves
                    Console.WriteLine("\nYou can't undo two times in a row!");
                }
                Console.WriteLine("\nWhat move would you like to make? Enter a number 0-8.");
                input = Console.ReadLine();
            }
            else
            {
                recentUndo = false;
            }


            while (!isLegal)
            {
                //     reading the users choice

                playerMove = int.Parse(input);
                for (int i = 0; i < Game.LegalMoves.Count; i++)
                {
                    if (playerMove == Game.LegalMoves[i]) isLegal = true;
                }

                //     invalid move
                if (isLegal == false)
                {
                    Console.WriteLine("\nNot a valid move! Try again!");
                    input = Console.ReadLine();
                }
            }

            //              playes choice of moves is showing on the board
            Board.Add(playerMove, player);
            Board.Display();
        }
    }
}
