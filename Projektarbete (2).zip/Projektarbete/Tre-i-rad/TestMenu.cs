﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tre_i_rad.DataStructure;

namespace Tre_i_rad
{
    public class TestMenu
    {
        // Static variable to hold the current data structure being tested.
        static BaseDatastructure? testDataStructure;

        // Main method to run the program
        public static void RunProgram()
        {
            bool exit = false; // Flag to control the exit from the program.

            do
            {
                // Clear the console and display the menu options.
                Console.Clear();
                Console.WriteLine("#---------------------------------------------#");
                Console.WriteLine("# What Data Structure would you like to test? #");
                Console.WriteLine("#---------------------------------------------#");
                Console.WriteLine("#  [1] - Stack                                #");
                Console.WriteLine("#  [2] - Linked List                          #");
                Console.WriteLine("#  [3] - Exit                                 #");
                Console.WriteLine("#---------------------------------------------#");

                int input;
                int count = 0;
                string choice = Console.ReadLine(); // Read user choice.

                // Process user choice using a switch statement.
                switch (choice)
                {
                    case "1":
                        // Initialize a stack data structure.
                        testDataStructure = new StackDatastructure();

                        Console.Clear();
                        Console.WriteLine("You chose Stack! Choose a number 1 - 10:");

                        input = int.Parse(Console.ReadLine()); // Get the number of elements to add.
                        for (int i = 0; i < input; i++)
                        {
                            testDataStructure.Add(RandomBoard()); // Add random boards to the stack.
                        }

                        Console.WriteLine($"\nYou added {input} random boards to the Stack, now it looks like this:");

                        for (int i = 0; i < input; i++)
                        {
                            DisplayBoard(testDataStructure.GetLast()); // Display the last board.
                            testDataStructure.RemoveLast(); // Remove the last board from the stack.
                        }
                        Console.WriteLine("\nDue to the nature of Stack, the data was deleted when showing all the boards!");
                        break;
                    case "2":
                        // Initialize a linked list data structure.
                        Console.Clear();
                        testDataStructure = new LinkedListDatastructure();

                        Console.Clear();
                        Console.WriteLine("You chose LinkedList! Choose a number 1 - 10:");

                        input = int.Parse(Console.ReadLine()); // Get the number of elements to add.
                        for (int i = 0; i < input; i++)
                        {
                            testDataStructure.Add(RandomBoard()); // Add random boards to the linked list.
                            count++;
                        }

                        Console.WriteLine($"\nYou added {input} random boards to the LinkedList, now it looks like this:");

                        for (int i = 0; i < input; i++)
                        {
                            DisplayBoard(testDataStructure.GetAtIndex(i)); // Display each board at the respective index.
                        }

                        Console.WriteLine("\nChoose number of boards to remove:");
                        input = int.Parse(Console.ReadLine()); // Get the number of elements to remove.
                        for (int i = 0; i < input; i++)
                        {
                            testDataStructure.RemoveLast(); // Remove the last board from the linked list.
                            count--;
                        }

                        Console.WriteLine($"\nYou removed {input} boards from the LinkedList, now it looks like this:");

                        for (int i = 0; i < count; i++)
                        {
                            DisplayBoard(testDataStructure.GetAtIndex(i)); // Display each remaining board.
                        }

                        break;
                    case "3":
                        // Exit the program.
                        Console.Clear();
                        exit = true;
                        break;
                    default:
                        // Handle invalid choice.
                        Console.WriteLine("Invalid choice. Please try again!");
                        break;
                }
                Console.WriteLine("\nPress any key to continue:");
                Console.ReadLine(); // Wait for user input before continuing.
            } while (!exit); // Repeat until the user chooses to exit.
        }

        // Method to display the tic-tac-toe board.
        public static void DisplayBoard(string[] board)
        {
            Console.WriteLine("\n|" + board[0] + "|" + board[1] + "|" + board[2] + "|");
            Console.WriteLine("|" + board[3] + "|" + board[4] + "|" + board[5] + "|");
            Console.WriteLine("|" + board[6] + "|" + board[7] + "|" + board[8] + "|");
        }

        // Method to generate a random tic-tac-toe board.
        public static string[] RandomBoard()
        {
            int num;
            string[] randomBoard = { "", "", "", "", "", "", "", "", "" };

            // Populate the board with random elements ("_", "X", "O").
            for (int i = 0; i < 9; i++)
            {
                Random rnd = new Random();
                num = rnd.Next(3);

                if (num == 0)
                {
                    randomBoard[i] = "_";
                }
                else if (num == 1)
                {
                    randomBoard[i] = "X";
                }
                else
                {
                    randomBoard[i] = "O";
                }
            }

            return randomBoard; // Return the generated board.
        }
    }
}
