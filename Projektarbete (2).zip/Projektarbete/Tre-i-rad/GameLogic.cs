﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tre_i_rad
{
    public class GameLogic
    {
        //                      Take care of the game and the game logic
        public static void RunProgram()
        {
            //          Variables to make the game work
            {
                CPU ai = new(new Board());
                Board b = new();
                Player human = new();

                string cpu;
                string player;

                //                  Choose symbol
                Console.WriteLine("Choose to play as 'X' or 'O':");
                player = Console.ReadLine().ToUpper();

                if (player == "X") cpu = "O";
                else cpu = "X";

                Board.Display();

                //                      The game loop, ends the loop when there's a result
                while (!Game.CheckWin(player, Board.ActiveBoard) && !Game.CheckDraw(player, Board.ActiveBoard))
                {
                    human.MakeMove(player, Board.ActiveBoard, Game.LegalMoves);
                    Game.LegalMoves = Board.CheckLegalMoves();

                    if (Game.CheckWin(player, Board.ActiveBoard) || Game.CheckDraw(player, Board.ActiveBoard)) break;
                    else
                    {
                        ai.MakeMove(cpu, Board.ActiveBoard, Game.LegalMoves);
                        Game.LegalMoves = Board.CheckLegalMoves();
                    }

                }

                //                      When game is over, return to main menu
                Board.Reset();
                Console.WriteLine("\nPress any key to continue:");
                Console.ReadLine();
            }
        }
    }
}
