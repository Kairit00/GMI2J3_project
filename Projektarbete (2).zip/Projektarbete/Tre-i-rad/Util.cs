﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tre_i_rad
{
    [ExcludeFromCodeCoverage]
    public class Util
        //                 Utility, takes care of the unput for the menu
    {
        public static void ResetProgram(Action input) // Generic Reset Method
        {
            Console.WriteLine();
            Console.WriteLine("Press any key to go back to the Main Menu");
            Console.ReadKey();
            Console.Clear();
            input.Invoke(); // Invoke the passed in Reset Method
        }

        //Reading the row and tries to parse the input string to a suitable genetric value of T value
        public static T? ReadLine<T>(Func<string, string>? inputModifier = null) // Optional function for modifing
        {
            var input = Console.ReadLine(); // Reading the input
            if (input == null) 
            {
                return default; // Íf it's null, return default
            }
            if (inputModifier != null)
            {
                input = inputModifier.Invoke(input);
            }
            if (typeof(T) == typeof(string)) // If T is a string, return the string
            {
                return (T)(object)input;
            }
            //Try to get TypeConverter, convert a string to T type with helk of Type converter and return a defualt or T
            try 
            {
                TypeConverter converter = TypeDescriptor.GetConverter(typeof(T));
                return (T)converter.ConvertFromString(input);
            }
            catch (NotSupportedException)
            {
                return default;
            }
        }
    }
}
